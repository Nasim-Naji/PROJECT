<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<style>
    .carousel-inner > .item > img,
    .carousel-inner > .item > a > img {
     width: 100%;
     margin: auto;
    }

    .bg-4 {
      background-color: #2f2f2f;
      color: #ffffff;
    }

    html {
        position: relative;
        min-height: 100%;
      }
</style>
