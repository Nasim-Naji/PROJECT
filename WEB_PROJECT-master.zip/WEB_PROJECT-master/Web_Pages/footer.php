<hr>
<div class="container-fluid" style="padding-left:0px;">
  <!-- Footer -->
<footer class="page-footer font-small blue bg-4 text-center" style="position:absolute;bottom:0;width:100%;">
  <br>
  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2019 Copyright, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a>
  </div>
  <!-- Copyright -->
  <br>
</footer>
<!-- Footer -->

</div>
