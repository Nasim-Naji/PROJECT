package model;

public interface ISkiiable {
	public boolean skiing();
}
