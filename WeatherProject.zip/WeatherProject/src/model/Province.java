package model;
import java.util.ArrayList;


public class Province  extends Area {
	private City capital;
	private Country country;
	private ArrayList<City> cities;

	public Province(String name, double latitude, double longitude, double population,Country country, City capital, ArrayList<City> cities) {
		super(name, latitude, longitude, population);
		this.capital = capital;
		this.cities = cities;
		this.country=country;
	}
	public City getCapital() {
		return capital;
	}

	public void setCapital(City capital) {
		this.capital = capital;
	}

	public ArrayList<City> getCities() {
		return cities;
	}

	public void setCities(ArrayList<City> cities) {
		this.cities = cities;
	}
	
	public void addCity(City city){
		cities.add(city);
	}
	

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

}
