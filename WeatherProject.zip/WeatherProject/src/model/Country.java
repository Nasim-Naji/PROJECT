package model;
import java.util.ArrayList;

public class Country extends Area{
	private City capital;
	private ArrayList<Province> provinces;
	private String iso2;
	
	public Country(String name, double latitude, double longitude, double population, City capital, ArrayList<Province> provinces, String iso2) {
		super(name, latitude, longitude, population);
		this.setCapital(capital);
		this.setProvinces(provinces);
		this.setIso2(iso2);
	}

	public City getCapital() {
		return capital;
	}

	public void setCapital(City capital) {
		this.capital = capital;
	}

	public ArrayList<Province> getProvinces() {
		return provinces;
	}

	public void setProvinces(ArrayList<Province> provinces) {
		this.provinces = provinces;
	}

	public String getIso2() {
		return iso2;
	}

	public void setIso2(String iso2) {
		this.iso2 = iso2;
	}
	
	public void addProvince(Province province){
		provinces.add(province);
	}
	
}
