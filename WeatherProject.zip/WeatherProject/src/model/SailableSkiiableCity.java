package model;

public class SailableSkiiableCity extends City implements ISailable,ISkiiable {

	public SailableSkiiableCity(String name, double latitude, double longitude,double population, int capitalStatus,Province province) {
		super(name, latitude, longitude, population, capitalStatus,province);
		
	}

	@Override
	public boolean sailing() {
		getWeather().FetchWeather();
		if (getWeather().getVisibility() > 1000){
			return true;
		}
		else
		return false;
	}

	@Override
	public boolean skiing() {
		getWeather().FetchWeather();
		if (getWeather().getWindSpeed() > 5 && getWeather().getWindSpeed() < 20 && getWeather().getWindGust() < 25){
			return true;
		}
		else
		return false;
	}
	
	@Override
	public String getCityType()
	{
		return "Sailable & Skiiable City";
	}

}
