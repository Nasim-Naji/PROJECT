package model;
import java.net.*;
import java.io.*;

import javax.json.*;

public class Weather {
	private String cityName;
	private String main;
	private String description;
	private String icon;
	private double temp;
	private double temp_min;
	private double temp_max;
	private double pressure;
	private double humidity;
	private int visibility;
	private double windSpeed;
	private double windDeg;
	private double windGust;
	
	
	public Weather(String cityName)
	{
		this.cityName=cityName;
	}
	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getMain() {
		return main;
	}

	public void setMain(String main) {
		this.main = main;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public double getTemp() {
		return temp;
	}

	public void setTemp(double temp) {
		this.temp = temp;
	}

	public double getTemp_min() {
		return temp_min;
	}

	public void setTemp_min(double temp_min) {
		this.temp_min = temp_min;
	}

	public double getTemp_max() {
		return temp_max;
	}

	public void setTemp_max(double temp_max) {
		this.temp_max = temp_max;
	}

	public double getPressure() {
		return pressure;
	}

	public void setPressure(double pressure) {
		this.pressure = pressure;
	}

	public double getHumidity() {
		return humidity;
	}

	public void setHumidity(double humidity) {
		this.humidity = humidity;
	}

	public int getVisibility() {
		return visibility;
	}

	public void setVisibility(int visibility) {
		this.visibility = visibility;
	}

	public double getWindSpeed() {
		return windSpeed;
	}

	public void setWindSpeed(double windSpeed) {
		this.windSpeed = windSpeed;
	}

	public double getWindDeg() {
		return windDeg;
	}

	public void setWindDeg(double windDeg) {
		this.windDeg = windDeg;
	}

	public double getWindGust() {
		return windGust;
	}

	public void setWindGust(double windGust) {
		this.windGust = windGust;
	}

	public void FetchWeather() {
		try {
			URL url = new URL(
					"http://api.openweathermap.org/data/2.5/weather?q="+ getCityName().replaceAll("�", "e")+ "&units=metric&appid=122a9b7457682449757326422f77a195");

			try (InputStream is = url.openStream();
					JsonReader rdr = Json.createReader(is)) 
			 {
				JsonObject obj = rdr.readObject();
				
				JsonArray results = obj.getJsonArray("weather");
				JsonObject weather = results.getValuesAs(JsonObject.class).get(0);
				setMain(weather.getString("main"));
				setDescription(weather.getString("description"));
				setIcon(weather.getString("icon"));

				setTemp(Double.parseDouble(obj.getJsonObject("main").get("temp").toString()));
				setTemp_min(Double.parseDouble(obj.getJsonObject("main").get("temp_min").toString()));
				setTemp_max(Double.parseDouble(obj.getJsonObject("main").get("temp_max").toString()));
				setPressure(Double.parseDouble(obj.getJsonObject("main").get("pressure").toString()));
				setHumidity(Double.parseDouble(obj.getJsonObject("main").get("humidity").toString()));
				
				if(obj.get("visibility")!=null)
				{
					setVisibility(Integer.parseInt(obj.get("visibility").toString()));
				}
								
				setWindSpeed(Double.parseDouble(obj.getJsonObject("wind").get("speed").toString()));
				setWindDeg(Double.parseDouble(obj.getJsonObject("wind").get("deg").toString()));
				if(obj.getJsonObject("wind").get("gust")!=null)
				{
					setWindGust(Double.parseDouble(obj.getJsonObject("wind").get("gust").toString()));
				}
				

			}
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
