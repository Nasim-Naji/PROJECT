package model;

public class City extends Area {
	private int capitalStatus;
	private Weather weather;
	private Province province;
	public City()
	{
		
	}
	public City(String name, double latitude, double longitude, double population, int capitalStatus,Province province){
		super(name, latitude, longitude, population);
		this.capitalStatus = capitalStatus;
		this.province=province;
		weather=new Weather(name);
	}
	public Province getProvince() {
		return province;
	}
	public void setProvince(Province province) {
		this.province = province;
	}
	
	public int getCapitalStatus(){
		return this.capitalStatus;
	}
	public void setcapitalStatus(int capitalStatus){
		this.capitalStatus = capitalStatus;
	}
	
	public Weather getWeather()
	{	
		weather.FetchWeather();
		return weather;
	}
	
	public boolean flying()
	{
		weather.FetchWeather();
		if (weather.getVisibility() > 5000 && weather.getWindSpeed() < 30){
			return true;
		}
		else
		return false;
	}
	
	public boolean biking()
	{
		weather.FetchWeather();
		if (weather.getTemp() > -5 && weather.getTemp() < 30){
			return true;
		}
		else
		return false;
	}
	
	
	public  String getCityType()
	{
		return "City";
	}
	

}
