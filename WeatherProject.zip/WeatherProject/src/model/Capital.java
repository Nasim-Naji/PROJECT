package model;

public class Capital {
	public final static int CAPITAl_PRIMARY = 1;
	public final static int CAPITAl_ADMIN = 2;
	public final static int CAPITAl_NONE = 3;
}
