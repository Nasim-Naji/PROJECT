package model;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class TestWeather {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		boolean isCorrect = false;
		Country country1 = new Country("Canada", 10, 10, 80000000, new City(),
				new ArrayList<Province>(), "CA");

		Province province1 = new Province("Ontario", 20, 20, 20000000,country1, new City(), new ArrayList<City>());
		Province province2 = new Province("Quebec", 20, 20, 17000000, country1,new City(), new ArrayList<City>());
		Province province3 = new Province("British Columbia", 20, 20, 30000000,country1, new City(), new ArrayList<City>());
		Province province4 = new Province("Alberta", 20, 20, 10000000,country1, new City(), new ArrayList<City>());
		Province province5 = new Province("Saskatchewan", 20, 20, 5000000,country1, new City(), new ArrayList<City>());

		City city1 = new SailableSkiiableCity("Toronto", 43.666667, -79.416667,5213000, Capital.CAPITAl_ADMIN, province1);
		City city2 = new SailableCity("Ottawa", 45.416667, -75.7, 1145000,Capital.CAPITAl_PRIMARY, province1);
		City city3 = new SkiiableCity("Montreal", 45.5, -73.583333, 3678000,Capital.CAPITAl_NONE, province2);
		City city4 = new SailableCity("Vancouver", 49.25, -123.133333, 2313328,Capital.CAPITAl_ADMIN, province3);
		City city5 = new SailableSkiiableCity("Calgary", 51.083333,-114.083333, 1110000, Capital.CAPITAl_NONE, province4);
		City city6 = new SkiiableCity("Edmonton", 53.55, -113.5, 1058000,Capital.CAPITAl_ADMIN, province4);

		City city7 = new SkiiableCity("Quebec", 46.8, -71.25, 624177,Capital.CAPITAl_ADMIN, province2);
		City city8 = new SailableCity("London", 48.450234, -123.343529, 289625,Capital.CAPITAl_NONE, province1);
		City city9 = new City("Victoria", 48.450234, -123.343529, 289625,Capital.CAPITAl_NONE, province3);
		City city10 = new City("Saskatoon", 52.133333, -106.666667, 198958,Capital.CAPITAl_ADMIN, province5);

		City[] cityList = new City[] { city1, city2, city3, city4, city5,city6, city7, city8, city9, city10 };

		for (int i = 0; i < cityList.length; i++) {
			System.out.println((i + 1) + "-" + cityList[i].getName() + " ("+ cityList[i].getProvince().getName() + ") "
					+ cityList[i].getProvince().getCountry().getName());
		}

		int index = 0;
		while (!isCorrect) {
			try {
				System.out.print("Please select the number of your city from bellow list:");
				input = new Scanner(System.in);
				index = input.nextInt();
				if (index > cityList.length || index < 1)
					isCorrect = false;
				else
					isCorrect = true;
			} catch (InputMismatchException ex) {
				System.out.println("Input error! You have to enter Integer number.");
				isCorrect = false;
			}
		}
		
		System.out.println("\n \n");
		Weather w = ((City)(cityList[index-1])).getWeather();
		w.FetchWeather();

		
		System.out.println("Your choice is: " + w.getCityName());
		System.out.println("Type of your choice is: " +(cityList[index-1]).getClass().getName());
		System.out.println("Main: " + w.getMain());
		System.out.println("Description: " + w.getDescription());
		System.out.println("Icon: " +w.getIcon());

		System.out.println("Temperature: "+w.getTemp());
		System.out.println("Min temp: "+w.getTemp_min());
		System.out.println("Max temp: "+w.getTemp_max());
		System.out.println("Pressure: "+w.getPressure());
		System.out.println("Humidity: "+w.getHumidity());
		System.out.println("Visibility : "+w.getVisibility());
		System.out.println("Wind speed: "+w.getWindSpeed());
		System.out.println("Wind direction: "+w.getWindGust());
		System.out.println("Wind gust: "+w.getWindGust());
		
		ArrayList<String> listactivity=listOfActivity(cityList[index-1]);
		if (listactivity.size()>0)
		{
			System.out.print("You can do : ");
			for (int i = 0; i < listactivity.size(); i++) {
				System.out.print(listactivity.get(i)+",");			
			}
		}
		else
		{
			System.out.print("You can not do any activity!");
		}
		System.out.println();
		input.close();
	}
	
	public static ArrayList<String> listOfActivity(Object obj)
	{
		ArrayList<String> list1=new ArrayList<String>(); 
		String ClassName=obj.getClass().getName();
		
		if(((City)obj).flying())
		{
			list1.add("Flying");
		}
		if(((City)obj).biking())
		{
			list1.add("Biking");
		}
		
		switch (ClassName) {
		case "SailableSkiiableCity":
			if(((SailableSkiiableCity)obj).sailing())
			{
				list1.add("Sailing");
			}
			if(((SailableSkiiableCity)obj).skiing())
			{
				list1.add("Skiing");
			}
			
			break;
			
		case "SailableCity":
			if(((SailableCity)obj).sailing())
			{
				list1.add("Sailing");
			}
			
			break;
		case "SkiiableCity":
			
			if(((SkiiableCity)obj).skiing())
			{
				list1.add("Skiing");
			}
			
			break;
		default:
			break;
		}
		
		
		
		
		return list1;
	}

}
