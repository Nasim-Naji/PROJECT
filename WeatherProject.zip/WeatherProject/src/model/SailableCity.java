package model;

public class SailableCity extends City implements ISailable {

	public SailableCity(String name, double latitude, double longitude, double population, int capitalStatus,Province province) {
		super(name, latitude, longitude, population, capitalStatus,province);
		
	}

	@Override
	public boolean sailing() {
		getWeather().FetchWeather();
		if (getWeather().getWindSpeed() > 5 && getWeather().getWindSpeed() < 20 && getWeather().getWindGust() < 25){
			return true;
		}
		else
		return false;
	}
	
	@Override
	public String getCityType()
	{
		return "Sailable City";
	}
}
