package model;

public abstract class Area implements Comparable<Area>{
	private String name;
	private double latitude;
	private double longitude;
	private double population;
	
	protected Area(){}
	protected Area(String name, double latitude, double longitude, double population){
		this.name = name;
		this.latitude = latitude;
		this.longitude = longitude;
		this.population = population;
	}
	public String getName(){
		return this.name;
	}
	public void setName(String name){
		this.name = name;
	}
	public double getLatitude(){
		return this.latitude;
	}
	public void setLatitude(double latitude){
		this.latitude = latitude;
	}
	public double getLongitude(){
		return this.longitude;
	}
	public void setLongitude(double longitude){
		this.longitude = longitude;
	}
	public double getPopulation(){
		return this.population;
	}
	public void setPopulation(double population){
		this.population = population;
	}
	
	@Override
	public int compareTo(Area arg0) {
		return this.getName().compareTo(arg0.getName());  
	}
	
	public int equals(Area arg0) {
		return this.getName().compareTo(arg0.getName());  
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null)
            return false;
		if (!(obj instanceof Area))
            return false;
		return this.name.equals(((Area) obj).name);
	}

}
