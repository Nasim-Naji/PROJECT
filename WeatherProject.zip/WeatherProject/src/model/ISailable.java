package model;

public interface ISailable {
 public boolean sailing();
}
