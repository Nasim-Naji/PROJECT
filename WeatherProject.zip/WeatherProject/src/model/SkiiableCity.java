package model;
public class SkiiableCity extends City implements ISkiiable {

	public SkiiableCity(String name, double latitude, double longitude,double population, int capitalStatus,Province province) {
		super(name, latitude, longitude, population, capitalStatus,province);
	}

	@Override
	public boolean skiing() {
		getWeather().FetchWeather();
		if (getWeather().getVisibility() > 1000) {
			return true;
		} else
			return false;
	}
	
	@Override
	public String getCityType()
	{
		return "Skiiable City";
	}
}
