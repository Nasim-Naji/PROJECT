package application;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;

import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import model.*;


public class Controller {
	public ArrayList<Province> provinces=new ArrayList<Province>();
	public ArrayList<City> cities=new ArrayList<City>();
	
	public Button btnSubmit;
	public Button btnQuit;
	public Button btnClear;
	public ComboBox<String> cmbCountry;
	public ComboBox<String> cmbProvince;
	public ComboBox<String> cmbCity;
	public ImageView imgIcon;
	public Label lblType;
	public Label lblMain;
	public Label lblDescription;
	public Label lblTemp;
	public Label lblMinTemp;
	public Label lblMaxTemp;
	public Label lblPressure;
	public Label lblHumidity;
	public Label lblVisibility;
	public Label lblWindSpeed;
	public Label lblWindDirection;
	public Label lblWindGust;
	public CheckBox chkSailing;
	public CheckBox chkSkiing;
	public CheckBox chkFlying;
	public CheckBox chkBiking;

	public void initialize() {
		loadCanadaLocations();
		loadUsaLocations();
		clearForm();
	}

	public void exitProgram() {
		Platform.exit();
	}

	public void fillCountryCombo() {
		cmbCountry.getItems().addAll("Canada", "USA");

	}

	public void fillProvinceCombo() {
		if (cmbCountry.getItems().size()==0) return;
		cmbProvince.getItems().clear();
		cmbCity.getItems().clear();
		String country = cmbCountry.getValue().toString();
		provinces.forEach((n) -> {
			if(n.getCountry().getName().equals(country))
			{
				cmbProvince.getItems().add(n.getName());
			}
		});
		
	}
	public void fillCityCombo() {
		if (cmbProvince.getItems().size()==0) return;
			cmbCity.getItems().clear();
			String province = cmbProvince.getValue().toString();
			cities.forEach((n) -> {
				if(n.getProvince().getName().equals(province))
				{
					cmbCity.getItems().add(n.getName());
				}
			});
			

	}
	
	public void loadCanadaLocations()
	{
		try (InputStream is = new FileInputStream("src/application/cities_ca.json");
				JsonReader rdr = Json.createReader(is)) 
		 {
			City city;
			Country country1 = new Country("Canada", 10, 10, 80000000, new City(),new ArrayList<Province>(), "CA");
			JsonArray obj = rdr.readArray();
			for (int i = 0; i < obj.size(); i++) {
				JsonObject cityobj = obj.getValuesAs(JsonObject.class).get(i);
				Province province=new Province(cityobj.getString("admin"), 0, 0, 0, country1, new City(), new ArrayList<City>());
				
				String cityName=cityobj.getString("city");
				double population= Double.parseDouble(cityobj.getString("population"));
				double latitude= Double.parseDouble(cityobj.getString("lat"));
				double longitude= Double.parseDouble(cityobj.getString("lng"));
				
				int capitalid= cityobj.getString("capital").equals("primary") ? Capital.CAPITAl_PRIMARY:cityobj.getString("capital").equals("admin") ?  Capital.CAPITAl_ADMIN: Capital.CAPITAl_NONE;
				
				if (latitude>45 || latitude<-35)
				{
					city=new SailableSkiiableCity(cityName,latitude, longitude,population,capitalid,province);
				}
				else
				{
					city=new SailableCity(cityName,latitude, longitude,population,capitalid,province);
				}
				
				
				
				if(!cities.contains(city))
				{
					cities.add(city);
				}
				
				if(!provinces.contains(province))
				{
					provinces.add(province);
				}
				
			}
			Collections.sort(provinces);
			Collections.sort(cities);
			
	     }
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	
	public void loadUsaLocations()
	{
		try (InputStream is = new FileInputStream("src/application/cities_usa.json");
				JsonReader rdr = Json.createReader(is)) 
		 {
			City city;
			Country country1 = new Country("USA", 10, 10, 80000000, new City(),new ArrayList<Province>(), "USA");
			JsonArray obj = rdr.readArray();
			for (int i = 0; i < obj.size(); i++) {
				JsonObject cityobj = obj.getValuesAs(JsonObject.class).get(i);
				Province province=new Province(cityobj.getString("state"), 0, 0, 0, country1, new City(), new ArrayList<City>());
				
				String cityName=cityobj.getString("city");
				double population= Double.parseDouble(cityobj.getString("population"));
				double latitude= Double.parseDouble(cityobj.getJsonNumber("latitude").bigDecimalValue().toString());
				double longitude= Double.parseDouble(cityobj.getJsonNumber("longitude").bigDecimalValue().toString());
				
				int capitalid= Capital.CAPITAl_NONE;
				
				if (latitude>45 || latitude<-35)
				{
					city=new SkiiableCity(cityName,latitude, longitude,population,capitalid,province);
				}
				else
				{
					city=new City(cityName,latitude, longitude,population,capitalid,province);
				}
				
				
				
				if(!cities.contains(city))
				{
					cities.add(city);
				}
				
				if(!provinces.contains(province))
				{
					provinces.add(province);
				}
				
			}
			Collections.sort(provinces);
			Collections.sort(cities);
			
	     }
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public void clearControls()
	{
		lblType.setText("");
		lblMain.setText("");
		lblDescription.setText("");
		lblTemp.setText("");
		lblMinTemp.setText("");
		lblMaxTemp.setText("");
		lblPressure.setText("");
		lblHumidity.setText("");
		lblVisibility.setText("");
		lblWindSpeed.setText("");
		lblWindDirection.setText("");
		lblWindGust.setText("");
		
		chkSailing.setSelected(false);
		chkSkiing.setSelected(false);
		chkFlying.setSelected(false);
		chkBiking.setSelected(false);
		
		imgIcon.setImage(null);
	}
	
	public void clearForm()
	{
		
		clearControls();
		cmbCountry.getItems().clear();
		cmbProvince.getItems().clear();
		cmbCity.getItems().clear();
		fillCountryCombo();
		
	}
	
	public void showWeatherAndActivity()
	{
		if(cmbCity.getItems().size()==0 || cmbCity.getValue()==null)
		{
			Alert alert = new Alert(AlertType.ERROR);
			alert.setContentText("No city has been selected!");
			alert.showAndWait();
			return;
		}
		
		clearControls();
		
		cities.forEach((n) -> {
			if(n.getName().equals(cmbCity.getValue().toString()))
			{
				City city=n;
				Weather w=city.getWeather();
				w.FetchWeather();
				
				lblType.setText(city.getCityType());
				lblMain.setText(w.getMain());
				lblDescription.setText(w.getDescription());
				
				try
				{
					Image image1 = new Image("http://openweathermap.org/img/w/"+w.getIcon()+".png");
			        imgIcon.setImage(image1);
				}
				catch(Exception e)
				{
					System.out.printf(e.getMessage());
				}
				
			
				lblTemp.setText(String.valueOf(w.getTemp()));
				lblMinTemp.setText(String.valueOf(w.getTemp_min()));
				lblMaxTemp.setText(String.valueOf(w.getTemp_max()));
				lblPressure.setText(String.valueOf(w.getPressure()));
				lblHumidity.setText(String.valueOf(w.getHumidity()));
				lblVisibility.setText(String.valueOf(w.getVisibility()));
				lblWindSpeed.setText(String.valueOf(w.getWindSpeed()));
				lblWindDirection.setText(String.valueOf(w.getWindDeg()));
				lblWindGust.setText(String.valueOf(w.getWindGust()));
				
				findActivity(city);
				
			}
		});
		
		
		
	}
	
	public  void findActivity(City cityObj)
	{			
		if(cityObj.flying())
		{
			chkFlying.setSelected(true);
		}
		if(cityObj.biking())
		{
			chkBiking.setSelected(true);
		}
		
		if (cityObj instanceof SailableSkiiableCity)
			{
				SailableSkiiableCity city=(SailableSkiiableCity) cityObj;
				if(city.sailing())
				{
					chkSailing.setSelected(true);
				}
				if(city.skiing())
				{
					chkSkiing.setSelected(true);
				}
			}	
			
		if (cityObj instanceof SailableCity)
		{
			SailableCity city=(SailableCity) cityObj;
			if(city.sailing())
			{
				chkSailing.setSelected(true);
			}
		}
			
			
		if (cityObj instanceof SkiiableCity)
		{
			SkiiableCity city=(SkiiableCity) cityObj;
			if(city.skiing())
			{
				chkSkiing.setSelected(true);
			}
		}
	}
	

}
